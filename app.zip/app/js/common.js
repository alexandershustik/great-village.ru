$(function() {

	$('.login').click(function(){
		$('.login-menu').toggleClass('close');
	});

	$('.admin-menu').click(function(){
		$('.sidebar').toggleClass('close');

		$('.main-m-menu-inner').addClass('close');
	});

	$('.close-admin-menu').click(function(){
		$('.sidebar').toggleClass('close');

		$('.main-m-menu-inner').addClass('close');
	});

	$('.m-main-menu').click(function(){
		$('.main-m-menu-inner').toggleClass('close');

		$('.sidebar').addClass('close');
	});

	$('.close-main-m-menu').click(function(){
		$('.main-m-menu-inner').toggleClass('close');

		$('.sidebar').addClass('close');
	});

	$('.filter-button').click(function(){
		$(this).next().toggleClass('close');
	});

	$('.filter-item').click(function(){
		//$(this).html('df');
		//$(this).parent().parent().prev('filter-button').html('df');
		$(this).parent().parent().prev().html($(this).html() + ' <i class="fas fa-caret-down"></i>');
		$(this).parent().parent().addClass('close');
	});
	
});
